import {useState} from "react"

const Form = () => {

 const [formData , setFormData] =    useState({
    name : "",
    lName  : "",
    email : "", 
    password : "",
    age : "",
    message : ""
 })
    const handleChange = (e) => {
            setFormData((prev) => (
                {...prev, [e.target.name] : e.target.value}
            ))

               
    }

    console.log('formData',formData)
    const handleSubmit = () => {

    }
    return (
        <>
            <h2>Form</h2>
            <form onSubmit={handleSubmit}>
                <table>
                    <tr>
                        <td>
                            <label>Name</label>
                            <input type="text" onChange={handleChange} name="name" />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label>Last Name</label>
                            <input type="text" onChange={handleChange} name="lName" />
                        </td>
                    </tr>

                    <tr>
                        <td>

                            <label>Email</label>
                            <input type="email" onChange={handleChange} name="email" />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label>Password</label>
                            <input type="password" onChange={handleChange} name="password" />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label>Age</label>
                            <input type="number" onChange={handleChange} name="age" />

                        </td>
                    </tr>

                    <tr>
                        <td>

                            <label>Message</label>
                            <input type="text" onChange={handleChange} name="message" />
                        </td>
                    </tr>
                </table>
            </form>
        </>
    )
}

export default Form;