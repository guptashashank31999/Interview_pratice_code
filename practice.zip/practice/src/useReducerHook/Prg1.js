import React, {useReducer} from 'react';

function Prg1(){  
    
    const incrementReducer = (state , action) => {
        if(action.type === "Inc"){
            return {increment : state.increment + 1}
        }
         if(action.type === "Dec"){
            return {decrement : state.decrement - 1}
        }
    }
    const [value , dispatchAction] = useReducer(incrementReducer , {increment : 4, decrement : 10})

console.log('object',value)
    return (
        <>
            <h2>Prg 1</h2>
            <button onClick={() => dispatchAction({type : "Inc"})}>Increment</button>
            <h2>Counter Increment: {value.increment}</h2>
            <button onClick={()=> dispatchAction({type : "Dec"})}>Decrement</button>
            <h2>Counter Decrement: {value.decrement}</h2>
        </>
    )
}

export default Prg1