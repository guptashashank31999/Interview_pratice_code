import NewContext from "./context";
const ContextState = (props) => {
const fixedValue = {
    first: "11111",
    second : "2222222"
}
    return (
        <NewContext.Provider value={fixedValue}>
            {props.children}
        </NewContext.Provider>
    )
}

export default ContextState;