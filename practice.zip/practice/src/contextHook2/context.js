import {createContext} from "react";

const newContext = createContext();

export default newContext;