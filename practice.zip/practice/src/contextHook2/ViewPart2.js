import React, {useContext} from 'react'
import newContext from './context';
const ViewPart2 = () => {

    const a = useContext(newContext);

    console.log('object',a)
  return (
    <div>
      <h2>View part 2 {a.first} {a.second}</h2>
    </div>
  )
}

export default ViewPart2
