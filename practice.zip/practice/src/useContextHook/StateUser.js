import NodeState from "./contest";

const StateUser = ({children}) => {
    const state = {
        "name" : "Shashank",
        "class" : "1D"
    }

    return (
        <NodeState.Provider value={state}>
            {children}
        </NodeState.Provider>
    )
}

export default StateUser;