import React from 'react'
import { useContext } from 'react'
import nodeState from './contest'
const ViewPart = () => {

const a = useContext(nodeState)
console.log("object",a)
  return (
    <div>
        <h2>This is about component {a.name}</h2>  
    </div>
  )
}

export default ViewPart
