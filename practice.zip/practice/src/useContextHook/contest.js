import { createContext } from "react";

const NodeState = createContext();

export default NodeState;