
import Search from './component/Search';
import ListRealatedProblem from './component2/ListRelateProblem';
import DropDown from './Dropdown/DropDown';
import FolderStructure from './FolderStructure/FolderStructure';
import explorer from "../src/FolderStructure/FolderData"
import Prg1 from "./useReducerHook/Prg1"
import ViewPart from './useContextHook/ViewPart';
import StateUser from './useContextHook/StateUser';
import ViewPart2 from './contextHook2/ViewPart2';
import ContextState from './contextHook2/ContextState';
import ViewPart3 from './contextHook3/ViewPart3';
import ContextState3 from './contextHook3/ContextState3';
import CounterClocks from './counterApp/CounterClock';
import Search30 from './May30/SearchP30';
import CheckBoxList from './May30/CheckBoxList';
import Form from './form/Form';

function App() {
  return (
    <div>
      {/* <Search /> */}
      {/* <ListRealatedProblem /> */}
      {/* <DropDown /> */}
      {/* <FolderStructure explorer ={explorer}/> */}
      {/* <Prg1/> */}
      {/* <StateUser>
           <ViewPart/>
      </StateUser> */}
      {/* <ContextState>
      <ViewPart2/>
      </ContextState> */}

      {/* <ContextState3>
      <ViewPart3/>
      </ContextState3> */}
      {/* <CounterClocks /> */}
      {/* <Search30 /> */}

      {/* <CheckBoxList /> */}
      <Form />
    </div>
  );
}

export default App;
