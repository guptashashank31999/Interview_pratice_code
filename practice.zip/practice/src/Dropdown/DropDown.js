import { data } from "./DropdownData";
import {useState} from 'react';

const DropDown = () =>{ 
        const [stateData, setStateData] = useState([])
    // console.log("data" , data)
    const handleChange = (e) => {
        let actualData = e.target.value;

        let findData = data.find(item => item.country_name === actualData).states
         setStateData(findData);
         let filterData = data.filter(item => item.country_name === actualData)

         console.log("filterData", filterData)
         console.log("findData", findData)


    }
    return (
        <>
        <label>
            country
        </label>
        <select onChange={(e)=> {handleChange(e)}}>
        {
            data.map(item => {
                return (
                    <option key={item.sortname}>{item.country_name}</option>
                )
            })
        }
        </select>

        <label>
            State
        </label>
        <select>

        {
            stateData.map(item => {
                return (
                    <option>{item.state_name}</option>
                )
            })
        }
        </select>
        </>
    )
}


export default DropDown;