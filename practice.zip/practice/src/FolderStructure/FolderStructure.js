import React, {useState} from "react";
const FolderStructure = ({explorer}) => {

const [expend, setExpend] = useState(false);

    console.log("explorerData", explorer)
    if(explorer.isFolder) {
        return (
            <div>
            <div style={{marginTop : "10px"}} onClick={() => setExpend(!expend)}>
                   📁 {explorer.name}
            </div>
    
            <div style={{display : expend ? "block" : "none" , paddingLeft : "25px"}}>
                {explorer.items.map(item => {
                    return (
                       <FolderStructure explorer={item}/>
                    )
                })}
            </div>
            </div>
        )
    }else{
      return  <span>🗃{explorer.name}</span>
    }
 
}

export default FolderStructure;