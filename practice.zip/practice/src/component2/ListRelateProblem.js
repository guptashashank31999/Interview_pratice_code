import {useState} from "react";


const ListRealatedProblem = () => {
    const data = ["mango" , "banana" , "apple"];
    const [copyData , setCopyData] = useState(data);

    const [isChecked, setIsChecked] = useState(new Array(data.length).fill(false));

   // console.log("handleCheckBox",isChecked)
    // const handleDelete = (id) => {
    //     const filterData = copyData.filter((as , i) => i !== id);
    //     setCopyData(filterData)
    // }
//    const handleCheckboxChange = (id) => {
//     setIsChecked((prevState) =>
//     prevState.map((checked, i) => (i === id ? !checked : checked))
//   );
//     }
const handleDelete = (index) =>{
    const filterData = copyData.filter((a,i)=> i !== index);
    setCopyData(filterData)
}
const handleCheckBox = (index) => {
    setIsChecked((prevState)=> prevState.map((checked, i )=> (i === index ? !checked : checked)))
}
    return (
        <>
           {/* <ul>
            {
                copyData.map( (a , i ) => (
                    <li key={a}>
                    <input type="checkbox" 
                        checked = {isChecked[i]}
                        onChange={() => handleCheckboxChange(i)}
                    />
                    {a}
                    {
                        isChecked[i] &&   <button onClick={() => handleDelete(i)}>delete</button>
                    }
                  
                    </li>

                ))
            }
           </ul> */}
           <ul>
            {
                copyData.map((a, i )=> (

                    <li>
                    <input type="checkbox" 
                        checked={isChecked[i]}
                        onChange={()=> handleCheckBox(i)}
                    />
                        {a}
                       { isChecked[i] && <button onClick={()=> handleDelete(i)}>Delete</button>}
                    </li>
                )
                
                )
            }
           </ul>


        </>
    )
}

export default ListRealatedProblem;