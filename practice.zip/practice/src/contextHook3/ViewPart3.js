import React, {useContext} from 'react'
import context3 from './context3';
const ViewPart3 = () => {

    const a = useContext(context3);
    console.log('object',a)
  return (
    <div>
      <h2>hello view3 {a.name}</h2>
    </div>
  )
}

export default ViewPart3
