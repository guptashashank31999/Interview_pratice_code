import {createContext} from "react";

const context3 = createContext();

export default context3;