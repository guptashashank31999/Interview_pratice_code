import Context3 from "./context3";

const ContextState3 = (props) => {
    const state = {
        name: "2222",
        class: "1D"
    }

    return (
        <Context3.Provider value={state}>
            {props.children}
        </Context3.Provider>
    )
}

export default ContextState3;