import {useState} from "react"

const CheckBoxList = () =>{

    const datas = ['Apple','Mango','Grapes','Banana']

    const [data , setData] = useState(datas)
    const [isChecked , setIsChecked] = useState(new Array(datas.length).fill(false));

    const handleDelete =(id)=>{
        let filterData = data.filter((_,i)=> i != id)
        setData(filterData)

    }

    const handleCheckBox =(id)=>{
        console.log('object',id)
        setIsChecked((prevState)=> 
        prevState.map((check,i)=> (i===id? !check : check))
        )
    }
    return(
        <>
            <h2>Check box list</h2>

            {data.map((a, i)=> {
                return (
                    <>
                    <li>
                    <input type="checkbox" checked={isChecked[i]} onChange={()=> handleCheckBox(i)} />
                    {a}

                    {isChecked[i] &&  <button onClick={()=>handleDelete(i)}> Delete</button>}
                   
                    </li>
                    </>
                )
            })}
        </>
    )
}

export default CheckBoxList;
