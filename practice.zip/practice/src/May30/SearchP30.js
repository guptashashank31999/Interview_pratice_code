import {useState} from "react";
import {userData} from "../data/UserData"

const Search30 = () =>{
    const [inputData , setInputData] = useState("");

    console.log('object',userData.find(us=> us.email.toLowerCase().includes(inputData)));
    return (
        <>
            <h3>Search 30</h3>
            <input type="text" placeholder="Search" onChange={(e)=> setInputData(e.target.value)} />
            <table>
                <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Gender</th>
                </tr>

                <tbody>

                {userData.filter(us => {
                    if(inputData === ""){
                        return us
                    }else{

                        return us.email.toLowerCase().includes(inputData)
                    }
                }).map(user => {
                    return <>
                            <tr>
                                <td>{user.first_name}</td>
                                <td>{user.last_name}</td>
                                <td>{user.email}</td>
                                <td>{user.gender}</td>

                            </tr>
                        </>
                })
                
                }
                </tbody>
            </table>
        </>
    )
}

export default Search30;