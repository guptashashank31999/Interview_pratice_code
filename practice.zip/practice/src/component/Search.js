import React, {useState} from "react"
import {userData} from "../data/UserData"
import "./Search.css"
const Search = () => {
    const [inputData, setInputData] = useState("")
    return (
        <div className="div1">
                <input type="text" placeholder="Search..." onChange={(e)=> {
                   setInputData(e.target.value);
                }}/>
            <table>
                <tbody>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Gender</th>
                    </tr>
                    {/* {
                        userData.filter(user => {
                            if(inputData.length === ""){
                                return user
                            }else {
                                return user.email.toLowerCase().includes(inputData.toLowerCase())
                            }
                        }).map((data) => (
                            <tr key={data.id}>
                                <td>{data.first_name}</td>
                                <td>{data.last_name}</td>
                                <td>{data.email}</td>
                                <td>  {data.gender}</td>
                            </tr>
                        ))
                    } */}

                      {
                       userData.filter(data =>{
                      if(inputData.length === ""){
                        return data
                      }else{
                        return data.email.toLowerCase().includes(inputData.toLowerCase())
                      }
                       
                       }).map(data=> (
                        <tr key={data.id}>
                                <td>{data.first_name}</td>
                                <td>{data.last_name}</td>
                                <td>{data.email}</td>
                                <td>  {data.gender}</td>
                            </tr>
                       ))
                    }
                </tbody>
            </table>
        </div>
    )
}

export default Search;