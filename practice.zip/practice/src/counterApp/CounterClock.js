import {useRef, useState} from "react"

const CounterClock = () =>{

    const [seconds , setSeconds] = useState(0)
    const data = useRef();
    let data2 = useRef(0);
    
    console.log('data.current',data.current)
    console.log('data2.current',data2.current)


    
    const handleStart = () =>{
        data.current = setInterval(()=>{

            setSeconds(prev => prev + 1)
        },1000)

        console.log('data',data.current)
        console.log('data2',data2.current)
    }

    const handleStop = () =>{
       clearInterval(data.current);
    }

    const handleReset = ()=> {
     setSeconds(0)   
    }

    return(
        <>
            <h2>Cunter Clock</h2>
            <h2>Seconds : {seconds}</h2>
            <button onClick={()=>handleStart()}>Start</button>
            <button onClick={()=> handleStop()}>Stop</button>
            <button onClick={()=> handleReset()}>Reset</button>

        </>
    )
}

export default CounterClock